

void validate_args(int argc, char** argv, 
		   int* nFrames, char*** Frames, int* verbo, int* factor,\
		   int* nPlot, char*** PlotNames);
