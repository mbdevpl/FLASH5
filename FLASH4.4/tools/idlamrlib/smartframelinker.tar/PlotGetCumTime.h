#define HEADER "/Header"


int
PlotGetCumTime(const char* plotname, double* time, const int verbo);
