#include <unistd.h> // symlinks
#include <stdio.h>  // printf, FILE*
#include <stdlib.h> // malloc
#include <string.h> // memset, strcat
#include <errno.h>  // error reporting


#include "validate_args.h"
#include "smartframelinker.h"
#include "PlotGetCumTime.h"

double min(const double a, const double b)
{
  if(a <= b) return a;
  else return b;
}

double max(const double a, const double b)
{
  if(a >= b) return a;
  else return b;
}


int 
main(int argc, char** argv)
{
  int i, j;
  char PREFIX[] = "link.";
  FILE* eout; // errors
  eout = stderr;
  FILE* wout; // warnings
  wout = stdout;
  int nFrames = 0;
  char** Frames = NULL;
  int verbo = DEFAULT_VERBO;
  int factor = 0;
  int nPlot = 0;
  char** PlotNames = NULL;
  double* times;
  int index;
  //char** Links = NULL; // names of the symlinks
  //int nLinks; // number of symlinks
  int indexlo = 0;
  int indexhi = 0;
  char* link = NULL;
  int bubbleflipped;
  double temp_d;
  char* temp_charstar;
  double cTimeMin = 0;
  double cTimeMax = 0;;
  double span;
  double speed;
  //int n = 0;
  char** outframe;
  double time;
  double oftime;
  int found;
  int fnmin, fnmax;

  validate_args((int) argc, (char**) argv, (int*) &nFrames, (char***) &Frames, (int*) &verbo, (int*) &factor, (int*) &nPlot, (char***) &PlotNames);
  if(factor <=0) {
    if(verbo >= VERBO_ERROR) {
      fprintf(eout, "Error:  Invalid slowdown factor = %i\n", factor);
    }
    return 1;
  }
  if(verbo >= VERBO_NORMAL) {
    printf("Working on %i plotfiles and %i frames\n", nPlot, nFrames);
  }
  index = indexlo;
  times = (double*) malloc(nPlot*sizeof(double));
  indexhi = factor*nFrames-1;
  for(i=0; i<nPlot; i++) {
    // open up each plotfile header and read the simulation time
    if(PlotGetCumTime(\
		      (char*) PlotNames[i], \
		      (double*) &(times[i]), \
		      (int) verbo))
    {
      // error, bad plotfile
      if(verbo >= VERBO_ERROR) {
	printf("Error:  \"%s\" Does not appear to be a valid PlotFile.  Aborting\n", PlotNames[i]);
      }
      return -1;
    }
    // plotfile was good
    if(i==0) {
      cTimeMin = times[0];
      cTimeMax = times[0];
    }
    cTimeMin = min(cTimeMin, times[i]);
    cTimeMax = max(cTimeMax, times[i]);
  }
  if(verbo >= VERBO_NORMAL) {
    printf("cTime ranges from %e to %e\n", cTimeMin, cTimeMax);
  }
  span = cTimeMax - cTimeMin;
  if(factor-1 > 0) speed = span/(factor-1);
  else return 1;
  if(verbo >= VERBO_EXTRA) {
    printf("There will be %e seconds of simulation time per movie frame\n", speed);
  }

  // sort plotfiles by cTime, and resort frames by the cTime of the matched plotfile.
  // simple bubble sort --ok because nplot probably < 1000
  if(nPlot > 1000) {
    if(verbo >= VERBO_WARN) {
      printf("Warning:  Sorting many plotfiles with the BubbleSort algorithm is slow.\n");
      printf("  If you intend to process this many plotfiles, it is reccomended that\n");
      printf("  that they be in order on the command line, or else rewrite this program\n");
      printf("  to use a faster sorting algorithm.\n");
    }
  }
  for(i=0; i < nPlot; i++) {
    bubbleflipped = 0;
    for(j=0; j < nPlot-1; j++) {
      if(times[j] > times[j+1]) {
	bubbleflipped = 1;
	temp_d = times[j];
	times[j] = times[j+1];
	times[j+1] = temp_d;
	temp_charstar = Frames[j];
	Frames[j] = Frames[j+1];
	Frames[j+1] = temp_charstar;
      }
    }
    if(bubbleflipped == 0) i = nPlot; // detect early sort completion
  }
  if(verbo >= VERBO_TRACE) {
    printf("bubblesort complete\n");
    for(i = 0; i<nPlot; i++) {
      printf("times[%i] = %e\n", i, times[i]);
    }
  }
  outframe = (char**) malloc(factor*sizeof(char*));
  time = cTimeMin;
  for(i=0; i<factor; i++) {
    // spread outframe times evenly between begin and end
    // then for each outframe, make it meet the frame nearest in time
    oftime = cTimeMin + i*speed;
    fnmin = 0;
    fnmax = nPlot-1;
    {
      found = 0;
      fnmin = 0;
      fnmax = nPlot-1;
      while(!found) {
	if(fnmax - fnmin == 1) {
	  if(verbo >= VERBO_TRACE) {
	    printf("Time[%i] = %e <= (oftime = %e) <= Time[%i] = %e\n", \
		   fnmin, times[fnmin], \
		   oftime, \
		   fnmax, times[fnmax]\
		   );
	  }
	  if(fabs(times[fnmax]-oftime) <= fabs(times[fnmin]-oftime)) {
	    outframe[i] = strdup(Frames[fnmax]);
	  }
	  else {
	    outframe[i] = strdup(Frames[fnmin]);
	  }
	  found = 1;
	}
	else if(oftime < times[(fnmin+fnmax)/2]) {
	  fnmax = (fnmin+fnmax)/2;
	}
	else if(oftime > times[(fnmin+fnmax)/2]) {
	  fnmin = (fnmin+fnmax)/2;
	}
	else {
	  outframe[i] = strdup(Frames[(fnmin+fnmax)/2]);
	  found = 1;
	}
      }
    }
    if(verbo >=VERBO_TRACE){
      printf("OutFrame[%i] = \"%s\"\n", i, outframe[i]);
    }
  }
  index = 0;
  for(i=0; i< factor; i++) {
    link = (char*) malloc((strlen(PREFIX) + 
			   (6) + //force 6 decimal places 
			   1) *
			  sizeof(char));
    memset(link, 0, (strlen(PREFIX) + 
		     (6) + 
		     1) *
	   sizeof(char));
    strcat(link, PREFIX);
    sprintf(link+strlen(PREFIX), "%.6i", index);
    if(verbo >= VERBO_NORMAL) {
      printf("Making link %s -> %s  ", link, outframe[i]);
    }
    if(symlink(outframe[i], link)) {
      if(verbo >= VERBO_ERROR) {
	printf("Error making link: %s\n", strerror(errno));
	errno = 0;
      }
    }
    else {
      if(verbo >= VERBO_NORMAL) {
	printf("Success\n");
      }
    }
    free(link);
    link = NULL;
    index++;
  }

  return 0;
}
