#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "PlotGetCumTime.h"
#include "smartframelinker.h"

#define MAXLEN 1024
// maximum header line length

int error_eof(const int verbo)
{
  printf("Error: Unexpected End-Of-File encountered.\n");
  return 1;
}

int
PlotGetCumTime(const char* plotname, double* time, const int verbo)
{

  if(plotname ==NULL) {
    if(verbo >= VERBO_ERROR) {
      printf("Error: PlotGetCumTime() called with null pointer to plotname\n");
    }
    return -1;
  }
  if(time ==NULL) {
    if(verbo >= VERBO_ERROR) {
      printf("Error: PlotGetCumTime() called with null pointer to time\n");
    }
    return -1;
  }
  int headerlen;
  char* header = NULL;
  int rootlen = strlen(plotname);
  headerlen = rootlen+strlen(HEADER);
  header = (char*) malloc(headerlen+1);
  header[headerlen] = '\0';
  strcpy(header, plotname);
  strcpy(header+rootlen, HEADER);
  if(verbo >= VERBO_TRACE) {
    printf("headerlen = %i\n", headerlen);
  }
  if(verbo >= VERBO_EXTRA) {
    printf("Plot header file = %s\n", header);
  }
  FILE* f_header = NULL;
  f_header = fopen(header, "r");
  if(!f_header) {
    if(verbo >= VERBO_ERROR) {
      printf("Error: Could not open header file %s for reading\n", header);
    }
    return -1;
  }
  else {
    if(verbo >= VERBO_TRACE) {
      printf("Header file pointer = 0x%x\n", (unsigned int) f_header);
    }
  }
  



  // initialize vars
  char* got = 0; // used to rest that we could grab a line from file
  char buf[MAXLEN]; // hols a line from file
  //char* junk = buf; // another way to access the buffer
  int i;

  // read Version String
  memset(buf, 0, MAXLEN);
    got=fgets(buf, MAXLEN, f_header);
  if(!got) {
    error_eof(verbo);
  }

  //h->versionlen = strlen(buf);
  //h->version = (char*) malloc(h->versionlen+1);
  //strncpy(h->version, buf, h->versionlen);
  //h->version[h->versionlen-1] = '\0';
  //h->versionlen--;
  //h->version = (char*) realloc(h->version, h->versionlen+1);
  //if(verbosity >=9) {
  //  printf("Version = \"%s\"\n", h->version);
  //}
  //if(strcmp(buf, "HyperCLaw-V1.1\n")) {
  //  if(strncmp(buf, "HyperCLaw-V1.1\n", 9)) {
  //    if(verbosity) {
  //	printf("Warning: Header file version does not match any known HyperCLaw.  I will try to convert anyway but this doesn't look good...\n");
  //    }
  //  }
  //  else {
  //    if(verbosity) {
  //	printf("Warning: Header file version is for unknown version of HyperCLaw.\n");
  //	printf("  This program was designed for HyperCLaw 1.1.  Other versions may work\n");
  //	printf("  but there are no guarantees.\n");
  //    }
  //  }
  // }
     
  // Read number of variables
  memset(buf, 0, MAXLEN);
  if(header) got=fgets(buf, MAXLEN, f_header);
  if(!got) error_eof(verbo);
  int nplot = 0;
  nplot = atoi(buf);
  //if(verbosity >= 3) {
  //  printf("Number of variables = %d\n", h->nplot);
  //}
  //if(!(h->nplot)) {
  //  if(verbosity) {
  //    printf("Warning: number of plotted quantities is zero or could not be understood.\n");
  //  }
  //  if(verbosity >= 5) {
  //    printf("Line choked on: %s\n", buf);
  //  }
  //}

  // read variable names
  //h->names = (char**) malloc(h->nplot*sizeof(char*));
  //h->nameslen = (int*) malloc(h->nplot*sizeof(int));
  for(i=0; i < nplot; i++) {
    memset(buf, 0, MAXLEN);
    if(header) got=fgets(buf, MAXLEN, f_header);
    if(!got) error_eof(verbo);
    //buf[strlen(buf)-1] = '\0';
    //h->nameslen[i] = strlen(buf)+1;
    //h->names[i] = (char*) malloc(h->nameslen[i]*sizeof(char));
    //strcpy(h->names[i], buf);
    //if(verbosity >= 6) printf("Variable[%i] = \"%s\"\n", i, h->names[i]);
  }

  // read # spatial dimensions
  memset(buf, 0, MAXLEN);
  if(header) got=fgets(buf, MAXLEN, f_header);
  if(!got) error_eof(verbo);
  //h->ndim = atoi(buf);
  //if(verbosity >= 6) {
  //  printf("Number of dimensions = %d\n", h->ndim);
  //}
  //if(!(h->ndim ) || h->ndim >= 4) {
  //  if(verbosity) {
  //    printf("Warning: number of dimensions is zero or could not be understood.\n");
  //  }
  //  if(verbosity >= 5) {
  //    printf("Line choked on: %s\n", buf);
  //  }
  //}
  
  // read cTime
  memset(buf, 0, MAXLEN);
  if(header) got=fgets(buf, MAXLEN, f_header);
  if(!got) error_eof(verbo);
  //*time = strtod(buf, &junk);
  *time = atof(buf);
  if(verbo >= VERBO_EXTRA) {
    printf("cTime = %e\n", *time);
    printf("(string) cTime = \"%s\"\n", buf);
  }
  if(f_header) fclose(f_header);

  return 0;
}
