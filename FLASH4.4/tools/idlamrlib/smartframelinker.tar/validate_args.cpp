#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "validate_args.h"
#include "smartframelinker.h"

void print_usage(char* calling);

void print_usage(char* calling)
{
  printf("Usage: %s --f# [OPTIONS] <FRAME1> .... <FRAMEN>\n", calling);
  printf("       %s --help\n", calling);
  printf("--help    Display this help and exit.\n");
  printf("--f#      How many frames to make\n");
  printf("OPTIONS\n");
  printf("  --v#         Set how verbose to be (0 is totlly silent, 5 is trace-level)\n");
  printf("  --interleve  Interpret filenames as having frames and plotfiles interleved.  Ex:\n");
  printf("               frame0 plot0 frame1 plot1 frame2 plot2 ...\n");
}

void validate_args(int argc, char** argv, \
		   int* nFrames, char*** Frames, int* verbo, int* factor,\
		   int* nPlot, char*** PlotNames)
{
  int nFiles = 0;
  char** FileNames = NULL;
  int i;  
  int interleved = 0;
  if(verbo) {
    if(*verbo >= VERBO_TRACE) {
      fprintf(stderr, "Entered validate_args()\n");
    }
  }
  if(!argv) {
    fprintf(stderr, "Fatal Error: validate_args() called with null pointer to argv.\n");
    exit(EXIT_FAILURE);
  }
  if(argc < 3) {
    print_usage(argv[0]);
    *nFrames = 0;
    *factor = 0;
    return;
  }
  int argvilen; // argv[i] length (by strlen() )
  for(i=1; i<argc; i++) {
    // parse all args (except argv[0] ) without regard to their order
    argvilen = strlen(argv[i]);
    if(0==strncmp(argv[i], "--", 2)) {
      if(0==strncmp(argv[i], "--v", 3)) {
	if(argvilen == 4) {
	  *verbo = atoi(argv[i]+3*sizeof(char));
	  if(*verbo >= VERBO_TRACE) {
	    fprintf(stderr, "Set verbo = %i\n", (int) *verbo);
	  }
	}
      }
      else if(0==strncmp(argv[i], "--f", 3)) {
	if(argvilen >=4 && argvilen <=6) { // between 1 and 999
	  *factor = atoi(argv[i]+3*sizeof(char));
	  if(*verbo >= VERBO_TRACE) {
	    fprintf(stderr, "Set factor = %i\n", (int) *factor);
	  }
	}
	else {
	  if(*verbo >= VERBO_WARN ) {
	    fprintf(stderr, "Warning: Ignoring invalid slowdown factor \"%s\"\n", 
		    argv[i]);
	  }
	}
      }
      else if(0==strncmp(argv[i], "--interleve", 11)) {
	interleved = 1;
      }
      else if(0==strncmp(argv[i], "--help", 6)) {
	print_usage(argv[0]);
      }
      else {
	if(*verbo) {
	  fprintf(stderr, 
		  "Warning: Unknown option \"%s\" ignored.  Continuuing.\n", argv[i]);
	}
      }
    }
    else {
      // token is not an option so assume it's a plotfile name
      nFiles += 1;
      if(*verbo >= VERBO_TRACE) {
	fprintf(stdout, "Set nFiles = %i\n", nFiles);
      }
      FileNames = (char**) realloc(FileNames, 
					   nFiles*sizeof(char*));
      FileNames[nFiles-1] = (char*) 
	malloc( (argvilen+1)*sizeof(char));
      
      strcpy(FileNames[nFiles-1], argv[i]);
      if(*verbo >= VERBO_TRACE) {
	fprintf(stdout, "Set FileNames[%i] = %s\n", 
		nFiles-1, FileNames[nFiles-1]);
      }
    }
  }
  if(*verbo == VERBO_UNSET) {
    *verbo = DEFAULT_VERBO;
  }
  if(*verbo >= VERBO_EXTRA) {
    for(i=0; i<argc; i++) {
      printf("argv[%i] = %s\n", i, argv[i]);
    }
  }
  if(nFiles % 2) { // odd number of files specified
    if(*verbo >= VERBO_ERROR) {
      fprintf(stderr, "Error:  Non matching list of frames and PlotFiles specified.  You must specify equal numbers of each.\n");
    }
  }
  else {
    *nPlot = 2;
    int NF2 = nFiles/2;
    *nPlot = NF2;
    *nFrames = NF2;
    *Frames = (char**) malloc(NF2*sizeof(char*));
    *PlotNames = (char**) malloc(NF2*sizeof(char*));
    if(interleved) {
      for(i=0; i< NF2; i++) {
	(*Frames)[i]    = strdup(FileNames[2*i+0]);
	free(FileNames[2*i+0]);
	(*PlotNames)[i] = strdup(FileNames[2*i+1]);
	free(FileNames[2*i+1]);
	if(*verbo >= VERBO_TRACE) {
	  printf("Frame[%i] = \"%s\",  Plot[%i] = \"%s\"\n", i, (*Frames)[i], i, (*PlotNames)[i]);
	}
      }
      free(FileNames);
    }
    else {
      for(i=0; i< NF2; i++) {
	(*Frames)[i]    = strdup(FileNames[i]);
	free(FileNames[i]);
	if(*verbo >= VERBO_TRACE) {
	  printf("Frame[%i] = \"%s\"\n", i, (*Frames)[i]);
	}
      }
      for(i=0; i< NF2; i++) {
	(*PlotNames)[i] = strdup(FileNames[i+NF2]);
	free(FileNames[i+NF2]);
	if(*verbo >= VERBO_TRACE) {
	  printf("Plot[%i] = \"%s\"\n", i, (*PlotNames)[i]);
	}
      }
      free(FileNames);
    }
  }
  if(*verbo >= VERBO_TRACE) {
    fprintf(stderr, "Exiting validate_args()\n");
  }
  return;
}
