#define DEFAULT_VERBO 3
#define VERBO_SUPERTRACE 6
// Explain every little tiny thing

#define VERBO_TRACE 5
// Tell about entering and exit functions, and major parts of functions

#define VERBO_EXTRA 4
// Tell about most data and calculations

#define VERBO_NORMAL 3
// Tell about major parts in the program and summary data

#define VERBO_WARN 2
// Tell about warnings and errors

#define VERBO_ERROR 1
// Tell only fatal errors

#define VERBO_SILENT 0
// Completely silent, even on errors

#define VERBO_UNSET -1
// Verbosity not initialized by user, be silent until
// user fails to tell us to be silent
